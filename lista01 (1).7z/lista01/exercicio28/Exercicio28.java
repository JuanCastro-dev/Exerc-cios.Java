package lista01.exercicio28;

public class Exercicio28 {
    public static void main(String[] args) {
        System.out.println("Contagem regressiva de 10 a 0");
        for (int i = 10; i>=0 ; i--){
            System.out.println(i);
        }
    }
}
